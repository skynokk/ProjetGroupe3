<?php

$word = array('the','quik','brow');

foreach($words as $word){
    echo '<pre>'.words.'</pre>';
}
