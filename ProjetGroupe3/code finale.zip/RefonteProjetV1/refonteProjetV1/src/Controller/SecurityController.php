<?php

namespace App\Controller;

use App\Entity\Localisation;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

use App\Entity\Personne;
use App\Entity\Client;
use App\Form\RegistrationType;

class SecurityController extends AbstractController
{
    /**
     * @Route("/inscription", name="security_registration")
     */
    public function registration(Request $request, ObjectManager $manager, UserPasswordEncoderInterface $encoder)
    {
        $user = new Personne();
        $client = new Client();
        $localisation = new Localisation();

        $form = $this->createForm(RegistrationType::class, $user);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {
            $mail = $form->get('mail')->getData();
            $adresse = $form->get('adresse')->getData();
            $complement = $form->get('complement_adresse')->getData();
            $ville = $form->get('ville')->getData();
            $cp = $form->get('code_postal')->getData();

            $localisation->setAdresse($adresse);
            $localisation->setComplementAdresse($complement);
            $localisation->setVille($ville);
            $localisation->setCodePostal($cp);

            $hash = $encoder->encodePassword($user, $user->getPassword());
            $user->setPassword($hash);

            $client->setAdresse($localisation);
            $client->setAdresseMail($mail);
            $client->setPersonne($user);

            $manager->persist($user);
            $manager->persist($localisation);
            $manager->persist($client);
            $manager->flush();

            return $this->redirectToRoute('inscriptionreussi');
        }

        return $this->render('security/registration.html.twig', [
            'form' => $form->createView()
        ]);
        
    }

      /**
     * @Route("/Inscriptionreussi",name="inscriptionreussi")
     */
    public function inscriptionreussi(){
        return $this->render('security/inscriptionreussi.html.twig');
    }

    /**
     * @Route("/connexion", name="security_login")
     */
    public function login(){
	    return $this->render('security/login.html.twig');
    }

    /**
     * @Route("/deconnexion", name="security_logout")
     */
    public function logout(){    }
}
