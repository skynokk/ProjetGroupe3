<?php


namespace App\Controller;


use App\Entity\BienImmobilier;
use App\Entity\Commenter;
use App\Entity\Localisation;
use App\Entity\Personne;
use App\Form\AjoutBien;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\RechercheForm;
use Symfony\Component\Security\Core\Security;

class ImmoController extends AbstractController
{



    /**
     * @Route("/", name="accueil")
     *
     */
    public function index()
    {
        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App:BienImmobilier');

        $AllBiens = $repository->getBiensNonVendus();
        $biensBanniere = $repository->getPlusRecents();

        for($i = 0; $i<8; $i++){
            if($i<sizeof($AllBiens)){
                $biens[$i] = $AllBiens[$i];
            }
        }

        return $this->render('immo/index.html.twig', [
            'controller_name' => "ImmoController",
            'liste_biens' => $biens,
            'banniere' => $biensBanniere
        ]);

    }

    /**
     * @Route("/search", name="recherche")
     *
     */
    public function search(Request $request, ObjectManager $manager){

        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App:BienImmobilier');

        $form = $this->createForm(RechercheForm::class);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {

            $nbPieces = $form->get('nbPieces')->getData();
            $type = $form->get('type_bien')->getData();
            $superficie = $form->get('superficie')->getData();
            $prixMax = $form->get('prixMax')->getData();
            $tri = $form->get('tri')->getData();

            $biensTries = $repository->getBiensTries($type, $nbPieces, $superficie, $prixMax, $tri);
            $biensBanniere = $repository->getPlusRecents();

            return $this->render('immo/index.html.twig', [
                'controller_name' => "ImmoController",
                'liste_biens' => $biensTries,
                'banniere' => $biensBanniere
            ]);

        }

        return $this->render('immo/recherche.html.twig', [
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/profil",name="profil_show")
     */
    public function profil_show(Security $security){

        $user = $security->getUser();

        return $this->render('immo/profil.html.twig',[
            'information'=> $user,
        ]);

    }


    /**
     * @Route("/catalogue/{id}",name="detailBien")
     */
    public function show($id ,Request $request,  ObjectManager $manager, Security $security){

        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App:Client');

        $user = $security->getUser();

        $repo = $this->getDoctrine()->getRepository(BienImmobilier::class);
        $bien = $repo->find($id);

        $vendeur = $bien->getVendeur()->getPersonne();

        return $this->render('immo/seul.html.twig',[
            'bien'=> $bien,
            'vendeur' => $vendeur
        ]);
    }


    /**
     * @Route("/dashboard",name="dashboard")
     */
    public function dashboard($id ,Request $request,  ObjectManager $manager, Security $security){

        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App:BienImmobilier');

        $biens = $repository->getBiensNonVendus();
        $biensBanniere = $repository->getPlusRecents();

        return $this->render('admins/dashboard.html.twig', [
            'controller_name' => "ImmoController",
            'liste_biens' => $biens
        ]);
    }

    /**
     * @Route("/achat",name="achat")
     */
    public function achat(){

        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App:BienImmobilier');

        $biens = $repository->getBiensNonVendus();
        $biensBanniere = $repository->getPlusRecents();

        return $this->render('immo/achat.html.twig', [
            'controller_name' => "ImmoController",
            'liste_biens' => $biens,
            'banniere' => $biensBanniere
        ]);
    }

    /**
     * @Route("/ajout_bien",name="ajout_bien")
     */
    public function ajoutbien(Request $request, ObjectManager $manager, Security $security){

        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App:Client');
        $repositoryAgence = $em->getRepository('App:Agence');

        $user = $security->getToken()->getUser();
        $idPersonne = $user->getId();
        $client = $repository->getClientByPersonne($idPersonne);

        $bien = new BienImmobilier();
        $localisation = new Localisation();

        $form = $this->createForm(AjoutBien::class);

        $form->handleRequest($request, $bien);

        if($form->isSubmitted() && $form->isValid()) {

            $adresse = $form->get('adresse')->getData();
            $comp = $form->get('complement_adresse')->getData();
            $ville = $form->get('ville')->getData();
            $cp = $form->get('code_postal')->getData();

            $localisation->setAdresse($adresse);
            $localisation->setComplementAdresse($comp);
            $localisation->setVille($ville);
            $localisation->setCodePostal($cp);


            $bien->setAdresse($localisation);

            if($bien->getEtage() == null){
                $bien->setEtage(0);
            }
            if($bien->getPrixMinimum() == null){
                $bien->setPrixMinimum($form->get('prixMiseEnVente')->getData());
            }

            $bien->setDateMiseEnVente(new \DateTime('now'));
            $bien->setAcheteur($client);
            $agence = $repositoryAgence->find(0);
            $bien->setAgence($agence);


            $manager->persist($localisation);
            $manager->persist($bien);
            $manager->flush();

        }

        return $this->render('immo/ajout/ajoutbien.html.twig',[
            'form' => $form->createView()
        ]);
    }


    /**
     * @Route("/admin",name="admin_show")
     */
    public function findAllUser(){
        $req = $this->getDoctrine()->getRepository(Personne::class);
        $users = $req->findAll();

        return $this->render('admins/index_admin.html.twig',[
            'users'=>$users,
        ]);
    }



    /**
     *@Route("/profil_admin/{id}",name="detaille_profil")
     *
     */
    public function profil_admin($id,Request $request,Personne $personne){
        $repo = $this->getDoctrine()->getRepository(Personne::class);
        $information = $repo->find($id);

        return $this->render('admins/profile_admin.html.twig',[
            'information'=> $information,
        ]);

    }


    /**
     * @Route("/profil_supp/{id}",name="product_delete")
     */
    public function delete(Personne $personne){
        $em =$this->getDoctrine()->getManager();
        $em->remove($personne);
        $em->flush();

        return $this->redirectToRoute('admin_show');
    }


}