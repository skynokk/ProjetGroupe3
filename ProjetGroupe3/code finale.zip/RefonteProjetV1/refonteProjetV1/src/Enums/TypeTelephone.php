<?php


namespace App\Enums;


abstract class TypeTelephone
{
    const TYPE_PORTABLE    = "portable";
    const TYPE_FIXE = "fixe";
    const TYPE_FAX = "fax";

    /** @var array user friendly named type */
    protected static $typeName = [
        self::TYPE_PORTABLE    => 'Téléphone Mobile',
        self::TYPE_FIXE => 'Téléphone Fixe',
        self::TYPE_FAX => 'Fax',
    ];

    /**
     * @param  string $typeShortName
     * @return string
     */
    public static function getTypeName($typeShortName)
    {
        if (!isset(static::$typeName[$typeShortName])) {
            return "Unknown type ($typeShortName)";
        }

        return static::$typeName[$typeShortName];
    }

    /**
     * @return array<string>
     */
    public static function getAvailableTypes()
    {
        return [
            self::TYPE_PORTABLE,
            self::TYPE_FIXE,
            self::TYPE_FAX
        ];
    }
}