<?php


namespace App\Enums;


abstract class TypeBien
{
    const TYPE_STUDIO    = "studio";
    const TYPE_APPARTEMENT = "appart";
    const TYPE_MAISON = "maison";
    const TYPE_VILLA  = "villa";
    const TYPE_AUTRE = "autre";

    /** @var array user friendly named type */
    protected static $typeName = [
        self::TYPE_STUDIO    => 'Studio',
        self::TYPE_APPARTEMENT => 'Appartement',
        self::TYPE_MAISON => 'Maison',
        self::TYPE_VILLA  => 'Villa',
        self::TYPE_AUTRE  => 'Autre',
    ];

    /**
     * @param  string $typeShortName
     * @return string
     */
    public static function getTypeName($typeShortName)
    {
        if (!isset(static::$typeName[$typeShortName])) {
            return "Unknown type ($typeShortName)";
        }

        return static::$typeName[$typeShortName];
    }

    /**
     * @return array<string>
     */
    public static function getAvailableTypes()
    {
        return [
            self::TYPE_STUDIO,
            self::TYPE_APPARTEMENT,
            self::TYPE_MAISON,
            self::TYPE_VILLA,
            self::TYPE_AUTRE
        ];
    }
}