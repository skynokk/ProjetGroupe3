<?php

namespace App\Repository;

use App\Entity\BienImmobilier;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

class BienImmobilierRepository extends \Doctrine\ORM\EntityRepository
{
    public function getBiensNonVendus(){
        $biens = $this->getEntityManager()->createQuery(
            'SELECT b from App:BienImmobilier b
            WHERE b.vendue = 0'
        )->getResult();

        return $biens;
    }

    public function getPlusRecents(){
        $banniere = $this->getEntityManager()->createQuery(
            'SELECT b from App:BienImmobilier b
            WHERE b.vendue = 0
            ORDER BY b.dateMiseEnVente DESC'
        )->setMaxResults(5)
            ->getResult();

        return $banniere;
    }

    public function getBiensTries($type, $nbPieces, $superficie, $prixMax, $tri)
    {
        $req = 'SELECT b from App:BienImmobilier b WHERE b.vendue = 0';

        if(!($type == null && $nbPieces == null && $superficie == null && $prixMax == null)){
            if($type != null){
                $req.=" AND b.TypeBien = '".$type."'";
            }
            if($nbPieces != null){
                $req.=' AND b.nombrePieces = '.$nbPieces;
            }
            if($superficie != null){
                $req.=' AND b.superficie >= '.$superficie;
            }
            if($prixMax != null){
                $req.=' AND b.prixMiseEnVente <= '.$prixMax;
            }
        }

        if($tri == 'date') {
            $req .= ' ORDER BY b.dateMiseEnVente DESC';
        }
        else{
            $req.=' ORDER BY b.visites DESC';
        }

        $biensTries = $this->getEntityManager()->createQuery(
            $req
        )->getResult();

        return $biensTries;
    }

    // /**
    //  * @return BienImmobilier[] Returns an array of BienImmobilier objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('b')
            ->andWhere('b.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('b.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?BienImmobilier
    {
        return $this->createQueryBuilder('b')
            ->andWhere('b.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
