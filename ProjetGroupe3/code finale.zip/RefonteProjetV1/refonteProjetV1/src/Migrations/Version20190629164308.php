<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190629164308 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE agent DROP FOREIGN KEY FK_268B9C9DA21BD112');
        $this->addSql('ALTER TABLE agent DROP FOREIGN KEY FK_268B9C9DD725330D');
        $this->addSql('ALTER TABLE agent ADD CONSTRAINT FK_268B9C9DA21BD112 FOREIGN KEY (personne_id) REFERENCES personne (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE agent ADD CONSTRAINT FK_268B9C9DD725330D FOREIGN KEY (agence_id) REFERENCES agence (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE client DROP FOREIGN KEY FK_C74404554DE7DC5C');
        $this->addSql('ALTER TABLE client DROP FOREIGN KEY FK_C7440455A21BD112');
        $this->addSql('ALTER TABLE client ADD CONSTRAINT FK_C74404554DE7DC5C FOREIGN KEY (adresse_id) REFERENCES localisation (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE client ADD CONSTRAINT FK_C7440455A21BD112 FOREIGN KEY (personne_id) REFERENCES personne (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE dependance DROP FOREIGN KEY FK_B43B9E1DBD95B80F');
        $this->addSql('ALTER TABLE dependance ADD CONSTRAINT FK_B43B9E1DBD95B80F FOREIGN KEY (bien_id) REFERENCES bien_immobilier (id) ON DELETE CASCADE');
        $this->addSql('DROP INDEX UNIQ_FCEC9EFF85E0677 ON personne');
        $this->addSql('ALTER TABLE photo DROP FOREIGN KEY FK_14B78418BD95B80F');
        $this->addSql('ALTER TABLE photo ADD CONSTRAINT FK_14B78418BD95B80F FOREIGN KEY (bien_id) REFERENCES bien_immobilier (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE telephone DROP FOREIGN KEY FK_450FF0106FE0925');
        $this->addSql('ALTER TABLE telephone ADD CONSTRAINT FK_450FF0106FE0925 FOREIGN KEY (proporietaire_id) REFERENCES personne (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE agent DROP FOREIGN KEY FK_268B9C9DD725330D');
        $this->addSql('ALTER TABLE agent DROP FOREIGN KEY FK_268B9C9DA21BD112');
        $this->addSql('ALTER TABLE agent ADD CONSTRAINT FK_268B9C9DD725330D FOREIGN KEY (agence_id) REFERENCES agence (id)');
        $this->addSql('ALTER TABLE agent ADD CONSTRAINT FK_268B9C9DA21BD112 FOREIGN KEY (personne_id) REFERENCES personne (id)');
        $this->addSql('ALTER TABLE client DROP FOREIGN KEY FK_C74404554DE7DC5C');
        $this->addSql('ALTER TABLE client DROP FOREIGN KEY FK_C7440455A21BD112');
        $this->addSql('ALTER TABLE client ADD CONSTRAINT FK_C74404554DE7DC5C FOREIGN KEY (adresse_id) REFERENCES localisation (id)');
        $this->addSql('ALTER TABLE client ADD CONSTRAINT FK_C7440455A21BD112 FOREIGN KEY (personne_id) REFERENCES personne (id)');
        $this->addSql('ALTER TABLE dependance DROP FOREIGN KEY FK_B43B9E1DBD95B80F');
        $this->addSql('ALTER TABLE dependance ADD CONSTRAINT FK_B43B9E1DBD95B80F FOREIGN KEY (bien_id) REFERENCES bien_immobilier (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_FCEC9EFF85E0677 ON personne (username)');
        $this->addSql('ALTER TABLE photo DROP FOREIGN KEY FK_14B78418BD95B80F');
        $this->addSql('ALTER TABLE photo ADD CONSTRAINT FK_14B78418BD95B80F FOREIGN KEY (bien_id) REFERENCES bien_immobilier (id)');
        $this->addSql('ALTER TABLE telephone DROP FOREIGN KEY FK_450FF0106FE0925');
        $this->addSql('ALTER TABLE telephone ADD CONSTRAINT FK_450FF0106FE0925 FOREIGN KEY (proporietaire_id) REFERENCES personne (id)');
    }
}
