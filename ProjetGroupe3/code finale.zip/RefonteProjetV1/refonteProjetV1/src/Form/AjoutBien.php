<?php

namespace App\Form;

use App\Entity\BienImmobilier;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class AjoutBien extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('typebien', ChoiceType::class, array(
                'choices'   => array('Maison' => 'maison', 'Appartement' => 'appart','Villa' => 'villa', 'Autre' => 'autre'),
                'required'  => true,
            ))
            ->add('superficie', null, array('label'=>'Superficie', 'required'=>true))
            ->add('PrecisionTypeBien', null, array('label'=>'Précisions', 'required'=>false))
            ->add('descriptionBien', null, array('label'=>'Desciption', 'required'=>false))
            ->add('nombrePieces', null, array('label'=>'Nombre de Pièces', 'required'=>true))
            ->add('etage', null, array('label'=>'Etage', 'required'=>false))
            ->add('prixMiseEnVente', null, array('label'=>'Prix', 'required'=>true))
            ->add('prixMinimum', null, array('label'=>'Prix Minimum', 'required'=>false))
            ->add('adresse_bien', null, array('label' => false, 'mapped' => false, 'required'=>true,))
            ->add('complement_adresse', null, array('label' => false,'required'=>false,'mapped' => false,))
            ->add('ville', null, array('label' => false,'mapped' => false, 'required'=>true,))
            ->add('code_postal', null, array('label' => false,'mapped' => false, 'required'=>true,))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => BienImmobilier::class,
        ]);
    }
}
