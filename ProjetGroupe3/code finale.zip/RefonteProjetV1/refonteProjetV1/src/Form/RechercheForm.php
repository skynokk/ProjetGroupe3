<?php

namespace App\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class RechercheForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('type_bien', ChoiceType::class, array(
                'choices'   => array('Maison' => 'maison', 'Appartement' => 'appart', 'Studio' => 'studio', 'Autre' => 'autre'),
                'required'  => false,
                'label' => "Type"
            ))
            ->add('nbPieces', null, array('label' => "Nombre de Pièces", 'required' => false,))
            ->add('prixMax',null, array('label' => "Prix Maximum", 'required' => false,))
            ->add('superficie', null, array('label' => "Superficie minimum", 'required' => false,))
            ->add('tri', ChoiceType::class, array(
                'choices'   => array('Date' => 'date', 'Vues' => 'vues'),
                'required'  => true,
                'label' => "Trier par : "
            ))
        ;
    }
}
