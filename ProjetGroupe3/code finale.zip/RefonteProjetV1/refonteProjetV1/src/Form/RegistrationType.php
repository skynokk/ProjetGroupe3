<?php

namespace App\Form;

use App\Entity\Personne;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class RegistrationType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom_personne', null, array('attr' => array('placeholder' => 'Nom',),'label' => false,))
            ->add('prenom_personne', null, array('attr' => array('placeholder' => 'Prenom',),'label' => false,))
            ->add('sexe', ChoiceType::class, array(
                'choices'   => array('Homme' => 'Homme', 'Femme' => 'Femme','Autre' => 'Autre'),
                'required'  => true,
            ))
            ->add('username', null, array('attr' => array('placeholder' => 'Username',),'label' => false,))
            ->add('password', PasswordType::class, array('attr' => array('placeholder' => 'Mot de Passe',),'label' => false,))
            ->add('mail', null, array('attr' => array('placeholder' => 'Mail',),'label' => false,'mapped' => false,))
            ->add('confirm_password', PasswordType::class, array('attr' => array('placeholder' => 'Confirmer le Mot de Passe',),'label' => false,'mapped' => false,))
            ->add('adresse', null, array('attr' => array('placeholder' => 'Adresse',),'label' => false,'mapped' => false,))
            ->add('complement_adresse', null, array('attr' => array('placeholder' => 'Complément d\'adresse',),'label' => false,'required'=>false,'mapped' => false,))
            ->add('ville', null, array('attr' => array('placeholder' => 'Ville',),'label' => false,'mapped' => false,))
            ->add('code_postal', null, array('attr' => array('placeholder' => 'Code Postal',),'label' => false,'mapped' => false,))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Personne::class,
        ]);
    }
}
