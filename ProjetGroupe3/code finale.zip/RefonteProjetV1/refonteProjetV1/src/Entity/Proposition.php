<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PropositionRepository")
 */
class Proposition
{

    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Client", inversedBy="propositions")
     * @ORM\JoinColumn(nullable=false)
     */
    private $client;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\BienImmobilier", inversedBy="propositions")
     * @ORM\JoinColumn(nullable=false)
     */
    private $bien;


    /**
     * @ORM\Column(type="float")
     */
    private $montantOffre;

    /**
     * @ORM\Column(type="date")
     */
    private $dateProposition;

    /**
     * @ORM\Column(type="float", nullable=true)
     */
    private $montantContreProposition;

    /**
     * @ORM\Column(type="date", nullable=true)
     */
    private $dateContreProposition;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $propositionAcceptee;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMontantOffre(): ?float
    {
        return $this->montantOffre;
    }

    public function setMontantOffre(float $montantOffre): self
    {
        $this->montantOffre = $montantOffre;

        return $this;
    }

    public function getDateProposition(): ?\DateTimeInterface
    {
        return $this->dateProposition;
    }

    public function setDateProposition(\DateTimeInterface $dateProposition): self
    {
        $this->dateProposition = $dateProposition;

        return $this;
    }

    public function getMontantContreProposition(): ?float
    {
        return $this->montantContreProposition;
    }

    public function setMontantContreProposition(?float $montantContreProposition): self
    {
        $this->montantContreProposition = $montantContreProposition;

        return $this;
    }

    public function getDateContreProposition(): ?\DateTimeInterface
    {
        return $this->dateContreProposition;
    }

    public function setDateContreProposition(?\DateTimeInterface $dateContreProposition): self
    {
        $this->dateContreProposition = $dateContreProposition;

        return $this;
    }

    public function getClient(): ?Client
    {
        return $this->client;
    }

    public function setClient(?Client $client): self
    {
        $this->client = $client;

        return $this;
    }

    public function getBien(): ?BienImmobilier
    {
        return $this->bien;
    }

    public function setBien(?BienImmobilier $bien): self
    {
        $this->bien = $bien;

        return $this;
    }

    public function getPropositionAcceptee(): ?bool
    {
        return $this->propositionAcceptee;
    }

    public function setPropositionAcceptee(?bool $propositionAcceptee): self
    {
        $this->propositionAcceptee = $propositionAcceptee;

        return $this;
    }
}
