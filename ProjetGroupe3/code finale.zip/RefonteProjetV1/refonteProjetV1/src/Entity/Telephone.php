<?php

namespace App\Entity;

use App\Enums\TypeTelephone;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TelephoneRepository")
 */
class Telephone
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $typeTelephone;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Personne", inversedBy="telephones")
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $proporietaire;

    /**
     * @ORM\Column(type="string")
     */
    private $numero;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeTelephone(): ?string
    {
        return $this->typeTelephone;
    }

    public function setTypeTelephone(string $typeTelephone): self
    {
        if(!in_array($typeTelephone, TypeTelephone::getAvailableTypes())){
            throw new \InvalidArgumentException("Type telephone invalide");
        }

        $this->typeTelephone = $typeTelephone;

        return $this;
    }

    public function getProporietaire(): ?Personne
    {
        return $this->proporietaire;
    }

    public function setProporietaire(?Personne $proporietaire): self
    {
        $this->proporietaire = $proporietaire;

        return $this;
    }

    public function getNumero(): ?string
    {
        return $this->numero;
    }

    public function setNumero(string $numero): self
    {
        $this->numero = $numero;

        return $this;
    }
}
