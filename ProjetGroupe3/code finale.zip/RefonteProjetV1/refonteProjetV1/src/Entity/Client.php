<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ClientRepository")
 * @UniqueEntity("email")
 * @UniqueEntity("personne")
 */
class Client
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(name="email", type="string", length=250, unique=true)
     */
    private $adresseMail;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\BienImmobilier", mappedBy="vendeur")
     */
    private $bienEnVente;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\BienImmobilier", mappedBy="acheteur")
     */
    private $biensAchetes;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Client", inversedBy="filleuls")
     */
    private $parrain;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Client", mappedBy="parrain")
     */
    private $filleuls;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Localisation")
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $adresse;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Personne")
     * @ORM\JoinColumn(nullable=false, unique=true, onDelete="CASCADE")
     */
    private $personne;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\BienImmobilier", inversedBy="personnesQuiAiment")
     */
    private $favoris;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Proposition", mappedBy="client")
     */
    private $propositions;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Agent", mappedBy="clientsAttribues")
     */
    private $agentsAttribues;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Communication", mappedBy="expediteur")
     */
    private $messagesEnvoyes;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Communication", mappedBy="destinataire")
     */
    private $messagesRecus;

    public function __construct()
    {
        $this->bienEnVente = new ArrayCollection();
        $this->biensAchetes = new ArrayCollection();
        $this->filleuls = new ArrayCollection();
        $this->favoris = new ArrayCollection();
        $this->propositions = new ArrayCollection();
        $this->agentsAttribues = new ArrayCollection();
        $this->messagesEnvoyes = new ArrayCollection();
        $this->messagesRecus = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAdresseMail(): ?string
    {
        return $this->adresseMail;
    }

    public function setAdresseMail(string $adresseMail): self
    {
        $this->adresseMail = $adresseMail;

        return $this;
    }

    /**
     * @return Collection|BienImmobilier[]
     */
    public function getBienEnVente(): Collection
    {
        return $this->bienEnVente;
    }

    public function addBienEnVente(BienImmobilier $bienEnVente): self
    {
        if (!$this->bienEnVente->contains($bienEnVente)) {
            $this->bienEnVente[] = $bienEnVente;
            $bienEnVente->setVendeur($this);
        }

        return $this;
    }

    public function removeBienEnVente(BienImmobilier $bienEnVente): self
    {
        if ($this->bienEnVente->contains($bienEnVente)) {
            $this->bienEnVente->removeElement($bienEnVente);
            // set the owning side to null (unless already changed)
            if ($bienEnVente->getVendeur() === $this) {
                $bienEnVente->setVendeur(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|BienImmobilier[]
     */
    public function getBiensAchetes(): Collection
    {
        return $this->biensAchetes;
    }

    public function addBiensAchete(BienImmobilier $biensAchete): self
    {
        if (!$this->biensAchetes->contains($biensAchete)) {
            $this->biensAchetes[] = $biensAchete;
            $biensAchete->setAcheteur($this);
        }

        return $this;
    }

    public function removeBiensAchete(BienImmobilier $biensAchete): self
    {
        if ($this->biensAchetes->contains($biensAchete)) {
            $this->biensAchetes->removeElement($biensAchete);
            // set the owning side to null (unless already changed)
            if ($biensAchete->getAcheteur() === $this) {
                $biensAchete->setAcheteur(null);
            }
        }

        return $this;
    }

    public function getParrain(): ?self
    {
        return $this->parrain;
    }

    public function setParrain(?self $parrain): self
    {
        $this->parrain = $parrain;

        return $this;
    }

    /**
     * @return Collection|self[]
     */
    public function getFilleuls(): Collection
    {
        return $this->filleuls;
    }

    public function addFilleul(self $filleul): self
    {
        if (!$this->filleuls->contains($filleul)) {
            $this->filleuls[] = $filleul;
            $filleul->setParrain($this);
        }

        return $this;
    }

    public function removeFilleul(self $filleul): self
    {
        if ($this->filleuls->contains($filleul)) {
            $this->filleuls->removeElement($filleul);
            // set the owning side to null (unless already changed)
            if ($filleul->getParrain() === $this) {
                $filleul->setParrain(null);
            }
        }

        return $this;
    }

    public function getAdresse(): ?Localisation
    {
        return $this->adresse;
    }

    public function setAdresse(?Localisation $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getPersonne(): ?Personne
    {
        return $this->personne;
    }

    public function setPersonne(?Personne $personne): self
    {
        $this->personne = $personne;

        return $this;
    }

    /**
     * @return Collection|BienImmobilier[]
     */
    public function getFavoris(): Collection
    {
        return $this->favoris;
    }

    public function addFavori(BienImmobilier $favori): self
    {
        if (!$this->favoris->contains($favori)) {
            $this->favoris[] = $favori;
        }

        return $this;
    }

    public function removeFavori(BienImmobilier $favori): self
    {
        if ($this->favoris->contains($favori)) {
            $this->favoris->removeElement($favori);
        }

        return $this;
    }

    /**
     * @return Collection|Proposition[]
     */
    public function getPropositions(): Collection
    {
        return $this->propositions;
    }

    public function addProposition(Proposition $proposition): self
    {
        if (!$this->propositions->contains($proposition)) {
            $this->propositions[] = $proposition;
            $proposition->setClient($this);
        }

        return $this;
    }

    public function removeProposition(Proposition $proposition): self
    {
        if ($this->propositions->contains($proposition)) {
            $this->propositions->removeElement($proposition);
            // set the owning side to null (unless already changed)
            if ($proposition->getClient() === $this) {
                $proposition->setClient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Agent[]
     */
    public function getAgentsAttribues(): Collection
    {
        return $this->agentsAttribues;
    }

    public function addAgentsAttribue(Agent $agentsAttribue): self
    {
        if (!$this->agentsAttribues->contains($agentsAttribue)) {
            $this->agentsAttribues[] = $agentsAttribue;
            $agentsAttribue->addClientsAttribue($this);
        }

        return $this;
    }

    public function removeAgentsAttribue(Agent $agentsAttribue): self
    {
        if ($this->agentsAttribues->contains($agentsAttribue)) {
            $this->agentsAttribues->removeElement($agentsAttribue);
            $agentsAttribue->removeClientsAttribue($this);
        }

        return $this;
    }

    /**
     * @return Collection|Communication[]
     */
    public function getMessagesEnvoyes(): Collection
    {
        return $this->messagesEnvoyes;
    }

    public function addMessagesEnvoye(Communication $messagesEnvoye): self
    {
        if (!$this->messagesEnvoyes->contains($messagesEnvoye)) {
            $this->messagesEnvoyes[] = $messagesEnvoye;
            $messagesEnvoye->setExpediteur($this);
        }

        return $this;
    }

    public function removeMessagesEnvoye(Communication $messagesEnvoye): self
    {
        if ($this->messagesEnvoyes->contains($messagesEnvoye)) {
            $this->messagesEnvoyes->removeElement($messagesEnvoye);
            // set the owning side to null (unless already changed)
            if ($messagesEnvoye->getExpediteur() === $this) {
                $messagesEnvoye->setExpediteur(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Communication[]
     */
    public function getMessagesRecus(): Collection
    {
        return $this->messagesRecus;
    }

    public function addMessagesRecus(Communication $messagesRecus): self
    {
        if (!$this->messagesRecus->contains($messagesRecus)) {
            $this->messagesRecus[] = $messagesRecus;
            $messagesRecus->setDestinataire($this);
        }

        return $this;
    }

    public function removeMessagesRecus(Communication $messagesRecus): self
    {
        if ($this->messagesRecus->contains($messagesRecus)) {
            $this->messagesRecus->removeElement($messagesRecus);
            // set the owning side to null (unless already changed)
            if ($messagesRecus->getDestinataire() === $this) {
                $messagesRecus->setDestinataire(null);
            }
        }

        return $this;
    }
}
