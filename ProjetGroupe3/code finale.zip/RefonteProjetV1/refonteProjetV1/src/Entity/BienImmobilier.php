<?php

namespace App\Entity;

use App\Enums\TypeBien;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\BienImmobilierRepository")
 */
class BienImmobilier
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=150)
     */
    private $TypeBien;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $PrecisionTypeBien;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $descriptionBien;

    /**
     * @ORM\Column(type="integer")
     */
    private $superficie;

    /**
     * @ORM\Column(type="integer")
     */
    private $nombrePieces;

    /**
     * @ORM\Column(type="integer")
     */
    private $etage;

    /**
     * @ORM\Column(type="float")
     */
    private $prixMinimum;

    /**
     * @ORM\Column(type="float")
     */
    private $prixMiseEnVente;

    /**
     * @ORM\Column(type="date")
     */
    private $dateMiseEnVente;

    /**
     * @ORM\Column(type="integer")
     */
    private $visites = 0;

    /**
     * @ORM\Column(type="boolean")
     */
    private $vendue = false;

    /**
     * @ORM\Column(type="date", nullable=true)
     */
    private $dateVente;

    /**
     * @ORM\Column(type="float", nullable=true)
     */
    private $prixVente;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Dependance", mappedBy="bien", orphanRemoval=true)
     */
    private $dependances;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Client", inversedBy="bienEnVente")
     * @ORM\JoinColumn(nullable=false)
     */
    private $vendeur;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Localisation")
     * @ORM\JoinColumn(nullable=false)
     */
    private $adresse;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Client", inversedBy="biensAchetes")
     */
    private $acheteur;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Agence", inversedBy="bienImmobiliers")
     * @ORM\JoinColumn(nullable=false)
     */
    private $agence;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Client", mappedBy="favoris")
     */
    private $personnesQuiAiment = 0;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Proposition", mappedBy="bien")
     */
    private $propositions;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Commentaire", mappedBy="bien", orphanRemoval=true)
     */
    private $commentaires;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Photo", mappedBy="bien", orphanRemoval=true)
     */
    private $photos;

    public function __construct()
    {
        $this->dependances = new ArrayCollection();
        $this->photos = new ArrayCollection();
        $this->personnesQuiAiment = new ArrayCollection();
        $this->propositions = new ArrayCollection();
        $this->commentaires = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeBien(): ?string
    {
        return $this->TypeBien;
    }

    public function setTypeBien(string $typeBien): self
    {
        if(!in_array($typeBien, TypeBien::getAvailableTypes())){
            throw new \InvalidArgumentException("Type bien invalide");
        }

        $this->TypeBien = $typeBien;

        return $this;
    }

    public function getPrecisionTypeBien(): ?string
    {
        return $this->PrecisionTypeBien;
    }

    public function setPrecisionTypeBien(?string $PrecisionTypeBien): self
    {
        $this->PrecisionTypeBien = $PrecisionTypeBien;

        return $this;
    }

    public function getDescriptionBien(): ?string
    {
        return $this->descriptionBien;
    }

    public function setDescriptionBien(?string $descriptionBien): self
    {
        $this->descriptionBien = $descriptionBien;

        return $this;
    }

    public function getSuperficie(): ?int
    {
        return $this->superficie;
    }

    public function setSuperficie(int $superficie): self
    {
        $this->superficie = $superficie;

        return $this;
    }

    public function getNombrePieces(): ?int
    {
        return $this->nombrePieces;
    }

    public function setNombrePieces(int $nombrePieces): self
    {
        $this->nombrePieces = $nombrePieces;

        return $this;
    }

    public function getEtage(): ?int
    {
        return $this->etage;
    }

    public function setEtage(int $etage): self
    {
        $this->etage = $etage;

        return $this;
    }

    public function getPrixMinimum(): ?float
    {
        return $this->prixMinimum;
    }

    public function setPrixMinimum(float $prixMinimum): self
    {
        $this->prixMinimum = $prixMinimum;

        return $this;
    }

    public function getPrixMiseEnVente(): ?float
    {
        return $this->prixMiseEnVente;
    }

    public function setPrixMiseEnVente(float $prixMiseEnVente): self
    {
        $this->prixMiseEnVente = $prixMiseEnVente;

        return $this;
    }

    public function getDateMiseEnVente(): ?\DateTimeInterface
    {
        return $this->dateMiseEnVente;
    }

    public function setDateMiseEnVente(\DateTimeInterface $dateMiseEnVente): self
    {
        $this->dateMiseEnVente = $dateMiseEnVente;

        return $this;
    }

    public function getVisites(): ?int
    {
        return $this->visites;
    }

    public function setVisites(int $visites): self
    {
        $this->visites = $visites;

        return $this;
    }

    public function getVendue(): ?bool
    {
        return $this->vendue;
    }

    public function setVendue(bool $vendue): self
    {
        $this->vendue = $vendue;

        return $this;
    }

    public function getDateVente(): ?\DateTimeInterface
    {
        return $this->dateVente;
    }

    public function setDateVente(?\DateTimeInterface $dateVente): self
    {
        $this->dateVente = $dateVente;

        return $this;
    }

    public function getPrixVente(): ?float
    {
        return $this->prixVente;
    }

    public function setPrixVente(?float $prixVente): self
    {
        $this->prixVente = $prixVente;

        return $this;
    }

    /**
     * @return Collection|Dependance[]
     */
    public function getDependances(): Collection
    {
        return $this->dependances;
    }

    public function addDependance(Dependance $dependance): self
    {
        if (!$this->dependances->contains($dependance)) {
            $this->dependances[] = $dependance;
            $dependance->setBien($this);
        }

        return $this;
    }

    public function removeDependance(Dependance $dependance): self
    {
        if ($this->dependances->contains($dependance)) {
            $this->dependances->removeElement($dependance);
            // set the owning side to null (unless already changed)
            if ($dependance->getBien() === $this) {
                $dependance->setBien(null);
            }
        }

        return $this;
    }

    public function getVendeur(): ?Client
    {
        return $this->vendeur;
    }

    public function setVendeur(?Client $vendeur): self
    {
        $this->vendeur = $vendeur;

        return $this;
    }

    public function getAdresse(): ?Localisation
    {
        return $this->adresse;
    }

    public function setAdresse(?Localisation $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getAcheteur(): ?Client
    {
        return $this->acheteur;
    }

    public function setAcheteur(?Client $acheteur): self
    {
        $this->acheteur = $acheteur;

        return $this;
    }

    public function getAgence(): ?Agence
    {
        return $this->agence;
    }

    public function setAgence(?Agence $agence): self
    {
        $this->agence = $agence;

        return $this;
    }

    /**
     * @return Collection|Client[]
     */
    public function getPersonnesQuiAiment(): Collection
    {
        return $this->personnesQuiAiment;
    }

    public function addPersonnesQuiAiment(Client $personnesQuiAiment): self
    {
        if (!$this->personnesQuiAiment->contains($personnesQuiAiment)) {
            $this->personnesQuiAiment[] = $personnesQuiAiment;
            $personnesQuiAiment->addFavori($this);
        }

        return $this;
    }

    public function removePersonnesQuiAiment(Client $personnesQuiAiment): self
    {
        if ($this->personnesQuiAiment->contains($personnesQuiAiment)) {
            $this->personnesQuiAiment->removeElement($personnesQuiAiment);
            $personnesQuiAiment->removeFavori($this);
        }

        return $this;
    }

    /**
     * @return Collection|Proposition[]
     */
    public function getPropositions(): Collection
    {
        return $this->propositions;
    }

    public function addProposition(Proposition $proposition): self
    {
        if (!$this->propositions->contains($proposition)) {
            $this->propositions[] = $proposition;
            $proposition->setBien($this);
        }

        return $this;
    }

    public function removeProposition(Proposition $proposition): self
    {
        if ($this->propositions->contains($proposition)) {
            $this->propositions->removeElement($proposition);
            // set the owning side to null (unless already changed)
            if ($proposition->getBien() === $this) {
                $proposition->setBien(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Commentaire[]
     */
    public function getCommentaires(): Collection
    {
        return $this->commentaires;
    }

    public function addCommentaire(Commentaire $commentaire): self
    {
        if (!$this->commentaires->contains($commentaire)) {
            $this->commentaires[] = $commentaire;
            $commentaire->setBien($this);
        }

        return $this;
    }

    public function removeCommentaire(Commentaire $commentaire): self
    {
        if ($this->commentaires->contains($commentaire)) {
            $this->commentaires->removeElement($commentaire);
            // set the owning side to null (unless already changed)
            if ($commentaire->getBien() === $this) {
                $commentaire->setBien(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Photo[]
     */
    public function getPhotos(): Collection
    {
        return $this->photos;
    }

    public function addPhoto(Photo $photo): self
    {
        if (!$this->photos->contains($photo)) {
            $this->photos[] = $photo;
            $photo->setBien($this);
        }

        return $this;
    }

    public function removePhoto(Photo $photo): self
    {
        if ($this->photos->contains($photo)) {
            $this->photos->removeElement($photo);
            // set the owning side to null (unless already changed)
            if ($photo->getBien() === $this) {
                $photo->setBien(null);
            }
        }

        return $this;
    }
}
