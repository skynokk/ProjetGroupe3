<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity(repositoryClass="App\Repository\AgentRepository")
 * @UniqueEntity("personne")
 */
class Agent
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=250)
     */
    private $adresseMail;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Agence", inversedBy="agents")
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $agence;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Personne")
     * @ORM\JoinColumn(nullable=false, unique=true, onDelete="CASCADE")
     */
    private $personne;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Client", inversedBy="agentsAttribues")
     */
    private $clientsAttribues;

    public function __construct()
    {
        $this->clientsAttribues = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAdresseMail(): ?string
    {
        return $this->adresseMail;
    }

    public function setAdresseMail(string $adresseMail): self
    {
        $this->adresseMail = $adresseMail;

        return $this;
    }

    public function getAgence(): ?Agence
    {
        return $this->agence;
    }

    public function setAgence(?Agence $agence): self
    {
        $this->agence = $agence;

        return $this;
    }

    public function getPersonne(): ?Personne
    {
        return $this->personne;
    }

    public function setPersonne(?Personne $personne): self
    {
        $this->personne = $personne;

        return $this;
    }

    /**
     * @return Collection|Client[]
     */
    public function getClientsAttribues(): Collection
    {
        return $this->clientsAttribues;
    }

    public function addClientsAttribue(Client $clientsAttribue): self
    {
        if (!$this->clientsAttribues->contains($clientsAttribue)) {
            $this->clientsAttribues[] = $clientsAttribue;
        }

        return $this;
    }

    public function removeClientsAttribue(Client $clientsAttribue): self
    {
        if ($this->clientsAttribues->contains($clientsAttribue)) {
            $this->clientsAttribues->removeElement($clientsAttribue);
        }

        return $this;
    }
}
