<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\DependanceRepository")
 */
class Dependance
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $nomDependance;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    /**
     * @ORM\Column(type="integer")
     */
    private $superficie;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\BienImmobilier", inversedBy="dependances")
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $bien;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNomDependance(): ?string
    {
        return $this->nomDependance;
    }

    public function setNomDependance(string $nomDependance): self
    {
        $this->nomDependance = $nomDependance;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getSuperficie(): ?int
    {
        return $this->superficie;
    }

    public function setSuperficie(int $superficie): self
    {
        $this->superficie = $superficie;

        return $this;
    }

    public function getBien(): ?BienImmobilier
    {
        return $this->bien;
    }

    public function setBien(?BienImmobilier $bien): self
    {
        $this->bien = $bien;

        return $this;
    }
}
