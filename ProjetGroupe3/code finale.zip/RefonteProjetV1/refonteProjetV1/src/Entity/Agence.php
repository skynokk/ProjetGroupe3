<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\AgenceRepository")
 */
class Agence
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $nomAgence;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\BienImmobilier", mappedBy="agence")
     */
    private $bienImmobiliers;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Localisation")
     * @ORM\JoinColumn(nullable=false)
     */
    private $adresse;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Agent", mappedBy="agence", orphanRemoval=true)
     */
    private $agents;

    public function __construct()
    {
        $this->bienImmobiliers = new ArrayCollection();
        $this->agents = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNomAgence(): ?string
    {
        return $this->nomAgence;
    }

    public function setNomAgence(string $nomAgence): self
    {
        $this->nomAgence = $nomAgence;

        return $this;
    }

    /**
     * @return Collection|BienImmobilier[]
     */
    public function getBienImmobiliers(): Collection
    {
        return $this->bienImmobiliers;
    }

    public function addBienImmobilier(BienImmobilier $bienImmobilier): self
    {
        if (!$this->bienImmobiliers->contains($bienImmobilier)) {
            $this->bienImmobiliers[] = $bienImmobilier;
            $bienImmobilier->setAgence($this);
        }

        return $this;
    }

    public function removeBienImmobilier(BienImmobilier $bienImmobilier): self
    {
        if ($this->bienImmobiliers->contains($bienImmobilier)) {
            $this->bienImmobiliers->removeElement($bienImmobilier);
            // set the owning side to null (unless already changed)
            if ($bienImmobilier->getAgence() === $this) {
                $bienImmobilier->setAgence(null);
            }
        }

        return $this;
    }

    public function getAdresse(): ?Localisation
    {
        return $this->adresse;
    }

    public function setAdresse(?Localisation $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    /**
     * @return Collection|Agent[]
     */
    public function getAgents(): Collection
    {
        return $this->agents;
    }

    public function addAgent(Agent $agent): self
    {
        if (!$this->agents->contains($agent)) {
            $this->agents[] = $agent;
            $agent->setAgence($this);
        }

        return $this;
    }

    public function removeAgent(Agent $agent): self
    {
        if ($this->agents->contains($agent)) {
            $this->agents->removeElement($agent);
            // set the owning side to null (unless already changed)
            if ($agent->getAgence() === $this) {
                $agent->setAgence(null);
            }
        }

        return $this;
    }
}
