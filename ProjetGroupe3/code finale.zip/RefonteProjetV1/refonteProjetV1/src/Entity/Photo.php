<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PhotoRepository")
 * @UniqueEntity("chemin_photo")
 */
class Photo
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    private $nomPhoto;

    /**
     * @ORM\Column(name="chemin_photo", type="string", length=500, unique=true)
     */
    private $cheminPhoto;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\BienImmobilier", inversedBy="photos")
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $bien;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNomPhoto(): ?string
    {
        return $this->nomPhoto;
    }

    public function setNomPhoto(?string $nomPhoto): self
    {
        $this->nomPhoto = $nomPhoto;

        return $this;
    }

    public function getCheminPhoto(): ?string
    {
        return $this->cheminPhoto;
    }

    public function setCheminPhoto(string $cheminPhoto): self
    {
        $this->cheminPhoto = $cheminPhoto;

        return $this;
    }

    public function getBien(): ?BienImmobilier
    {
        return $this->bien;
    }

    public function setBien(?BienImmobilier $bien): self
    {
        $this->bien = $bien;

        return $this;
    }
}
